import { cart ,removeFromCart,saveToStorage} from "../data/cart.js";
import { products } from "../data/products.js";
// import {formatCurrency} from "/utils/money.js";
import { formatCurrency } from "./utils/money.js";
import { calculateCartQuantity } from "../data/cart.js";
import { updateQuantity } from "../data/cart.js";
import dayjs from 'https://unpkg.com/supersimpledev@8.5.0/dayjs/esm/index.js';
import { deliveryOptions } from "../data/deliveryOptions.js";
let cartSummaryHtml ="";
cart.forEach((cartItem)=>{
  const productId = cartItem.productId;
  let matchingProduct;
  products.forEach((product)=>{
    if(product.id== productId){
      matchingProduct = product;
    }
  });
  console.log(matchingProduct);
  const deliveryOptionId = cartItem.deliveryOptionId || '1';
  const deliveryOption = deliveryOptions.find((option) => option.id === deliveryOptionId)
    || deliveryOptions[0];

  if (!cartItem.deliveryOptionId) {
    cartItem.deliveryOptionId = deliveryOption.id;
    saveToStorage();
  }
  const today = dayjs();
  const deliveryDate = today.add(
    deliveryOption.deliveryDays,
    'days'
  );
  const dateString = deliveryDate.format('dddd, MMMM D');

  cartSummaryHtml+= `<div class="cart-item-container js-cart-item-container-${matchingProduct.id}">
      <div class="delivery-date">
        Delivery date: ${dateString}
      </div>

      <div class="cart-item-details-grid">
        <img class="product-image"
          src="${matchingProduct.image}">

        <div class="cart-item-details">
          <div class="product-name">
            ${matchingProduct.name}
          </div>
          <div class="product-price">
            $${formatCurrency(matchingProduct.priceCents)};
          </div>
          <div class="product-quantity">
            <span>
              Quantity: <span class="quantity-label js-quantity-label-${matchingProduct.id}">${cartItem.quantity}</span>
            </span>
            <span class="update-quantity-link link-primary js-update-link"
              data-product-id="${matchingProduct.id}">
              Update
            </span>
            <input class="quantity-input js-quantity-input-${matchingProduct.id}">
            <span class="save-quantity-link link-primary js-save-link"
              data-product-id="${matchingProduct.id}">
              Save
            </span>
            <span class="delete-quantity-link link-primary js-delete-link" 
              data-product-id="${matchingProduct.id}">
              Delete
            </span>
          </div>
        </div>

        <div class="delivery-options">
          <div class="delivery-options-title">
            Choose a delivery option:
          </div>
          ${deliveryOptionsHTML(matchingProduct,cartItem)};
        </div>
      </div>
    </div>`;
});
console.log(cartSummaryHtml);
document.querySelector('.order-summary-js').innerHTML=cartSummaryHtml;

function deliveryOptionsHTML(matchingProduct,cartItem){
  let html = '';

  deliveryOptions.forEach((deliveryOption)=>{
    const today = dayjs();
    const deliveryDate = today.add(
      deliveryOption.deliveryDays,
      'days'
    );
    const priceString = deliveryOption.priceCents === 0
      ? 'FREE'
      : `$${formatCurrency(deliveryOption.priceCents)} -`;
    
    const dateString = deliveryDate.format('dddd, MMMM D');
    const isChecked = deliveryOption.id === cartItem.deliveryOptionId;
    html+=`<div class="delivery-option">
      <input type="radio"
        ${isChecked ? 'checked' : ''}
        class="delivery-option-input"
        name="delivery-option-${matchingProduct.id}">
      <div>
        <div class="delivery-option-date">
          ${dateString}
        </div>
        <div class="delivery-option-price">
          ${priceString} Shipping
        </div>
      </div>
    </div>`
  });
  return html;
  
}
document.querySelectorAll('.js-delete-link').forEach((link)=>{
  link.addEventListener('click',()=>{
    console.log('delete');
    const productId = link.dataset.productId;
    removeFromCart(productId);
    console.log(cart);
    const container = document.querySelector(
      `.js-cart-item-container-${productId}`
    );
    container.remove();
    // saveToStorage();
  });
});
document.querySelectorAll('.js-update-link')
  .forEach((link) => {
    link.addEventListener('click', () => {
      const productId = link.dataset.productId;
      const container = document.querySelector(
        `.js-cart-item-container-${productId}`
      );
      container.classList.add('is-editing-quantity');
    });
  });
function updateCartQuantity() {

  const cartQuantity = calculateCartQuantity();
  document.querySelector('.js-return-to-home-link')
    .innerHTML = `${cartQuantity} items`;
}

updateCartQuantity();
document.querySelectorAll('.js-save-link')
  .forEach((link) => {
    link.addEventListener('click', () => {
      const productId = link.dataset.productId;

      const quantityInput = document.querySelector(
        `.js-quantity-input-${productId}`
      );
      const newQuantity = Number(quantityInput.value);
      if (newQuantity < 0 || newQuantity >= 1000) {
        alert('Quantity must be at least 0 and less than 1000');
        return;
      }
      updateQuantity(productId, newQuantity);
      const container = document.querySelector(
        `.js-cart-item-container-${productId}`
      );
      container.classList.remove('is-editing-quantity');
      const quantityLabel = document.querySelector(
        `.js-quantity-label-${productId}`
      );
      

      quantityLabel.innerHTML = newQuantity;

      updateCartQuantity();
    });
  });

